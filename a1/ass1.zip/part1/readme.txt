in command line, execute:
`python wine_predictor.py wine-training wine-test`

to change strength of classification, change line 23 in wine_predictor.py to be what k value you want