in command line, execute:
`python hepatitis_decision_tree.py hepatitis-training hepatitis-test`

to test all sample runs, execute:
`python hepatitis_decision_tree_run.py`
